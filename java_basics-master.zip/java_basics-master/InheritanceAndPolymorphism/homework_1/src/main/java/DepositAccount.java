public class DepositAccount extends BankAccount {

}
