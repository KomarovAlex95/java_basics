public class Operator implements Employee{

    @Override
    public int getMonthSalary() {
        return FIXED_PART_OF_SALARY;
    }
}
