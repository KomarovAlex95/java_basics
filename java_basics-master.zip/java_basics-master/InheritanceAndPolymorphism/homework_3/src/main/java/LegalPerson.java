public class LegalPerson extends Client {
}
