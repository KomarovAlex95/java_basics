public class IndividualBusinessman extends Client {
}
