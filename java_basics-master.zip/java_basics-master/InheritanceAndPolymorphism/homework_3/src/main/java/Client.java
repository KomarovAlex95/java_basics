public abstract class Client {

    public double getAmount() {
        //TODO: реализуйте метод и удалите todo
        return 0;
    }

    public void put(double amountToPut) {
        //TODO: реализуйте метод и удалите todo
    }

    public void take(double amountToTake) {
        //TODO: реализуйте метод и удалите todo
    }

}
