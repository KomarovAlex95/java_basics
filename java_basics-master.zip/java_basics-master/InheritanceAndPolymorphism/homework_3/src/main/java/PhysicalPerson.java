public class PhysicalPerson extends Client {
}
