import java.util.Collections;
import java.util.List;

public class EmailList {

    public void add(String email) {
        // TODO: валидный формат email добавляется
    }

    public List<String> getSortedEmails() {
        // TODO: возвращается список электронных адресов в алфавитном порядке
        return Collections.emptyList();
    }

}
