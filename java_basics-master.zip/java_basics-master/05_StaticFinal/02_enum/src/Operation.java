public enum Operation {
    ADD, SUBTRACT, MULTIPLY
}
