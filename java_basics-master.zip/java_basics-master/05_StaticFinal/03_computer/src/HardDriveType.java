public enum HardDriveType {
    HDD, SSD
}
