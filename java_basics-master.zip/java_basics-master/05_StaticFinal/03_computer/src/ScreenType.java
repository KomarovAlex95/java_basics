public enum ScreenType {
    IPS, TN, VA
}
