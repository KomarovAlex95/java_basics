public class CompanyClient extends Client {
}
