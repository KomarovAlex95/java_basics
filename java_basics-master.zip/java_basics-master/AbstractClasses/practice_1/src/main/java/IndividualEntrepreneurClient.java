public class IndividualEntrepreneurClient extends Client {
}
