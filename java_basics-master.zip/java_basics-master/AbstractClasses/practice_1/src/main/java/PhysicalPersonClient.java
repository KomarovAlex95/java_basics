public class PhysicalPersonClient extends Client {
}
