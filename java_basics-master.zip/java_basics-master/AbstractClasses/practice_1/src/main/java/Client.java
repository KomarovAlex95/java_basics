public abstract class Client {

    public double getAmount() {
        //TODO: реализуйте метод и удалите todo
        return 0;
    }

    public void put(double amount) {
        //TODO: реализуйте метод и удалите todo
    }

    public void take(double amount) {
        //TODO: реализуйте метод и удалите todo
    }

}
