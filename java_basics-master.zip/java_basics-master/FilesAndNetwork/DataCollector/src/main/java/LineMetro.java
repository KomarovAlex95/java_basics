public class LineMetro {
    private String nameLine;
    private String numberLine;

    public LineMetro(String nameLine, String numberLine) {
        this.nameLine = nameLine;
        this.numberLine = numberLine;
    }

    public String getNameLine() {
        return nameLine;
    }

    public String getNumberLine() {
        return numberLine;
    }

}
