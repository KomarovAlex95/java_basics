
public class MetroDepth {
    private String name;
    private String depth;

    public String getName() {
        return name;
    }

    public String getDepth() {
        return depth;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDepth(String depth) {
        this.depth = depth;
    }

    public MetroDepth(String name, String depth) {
        this.name = name;
        this.depth = depth;
    }



}
