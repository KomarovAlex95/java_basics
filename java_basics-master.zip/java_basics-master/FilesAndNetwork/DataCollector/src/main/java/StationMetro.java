public class StationMetro {
    private String nameStation;
    private String numberLineStation;

    public StationMetro(String nameStation, String numberLineStation) {
        this.nameStation = nameStation;
        this.numberLineStation = numberLineStation;
    }


    public String getNameStation() {
        return nameStation;
    }

    public String getNumberLineStation() {
        return numberLineStation;
    }

}
